def foo(name):
    return f'Hello {name}!'


def get_name_from_ordered_dict():
    print('get_name_from_ordered_dict')


if __name__ == "__main__":
    print(foo('Volodymyr'))
