from my_package import *

def mul(a):
    return a * 5


if __name__ == "__main__":
    print(foo('Natalia'))
    print(sum(1, 4))
    # print(mul(5, 6))
    # log('hello world')
    print(mul(5))
    print(foo('Test'))
    # get_value()

