def log(text):
    print(f'Printing: {text}')


def foo():
    return 'We are inside info.py'
